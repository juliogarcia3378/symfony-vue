# InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Event ID. | [optional] 
**game_name** | **string** | Game Name. | [optional] 
**times_played** | **int** | Times Played. | [optional] 
**top_score** | **int** | Top Score. | [optional] 
**top_player** | **string** | Top player name. | [optional] 
**last_updated** | **string** | Last Updated Timestamp. . | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


